const CACHE_NAME = 'graphpaper-v1';
const OFFLINE_URL = 'index.html';
const FILES = [
  '/', '/index.html', '/style.css', '/app.js', '/manifest.json',
  'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js'
];

self.addEventListener('install', function(evt){
  evt.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(FILES)));
  self.skipWaiting();
});
self.addEventListener('activate', evt => { evt.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', evt => {
  const url = new URL(evt.request.url);
  if (FILES.includes(url.pathname) || FILES.includes(evt.request.url)){
    evt.respondWith(caches.match(evt.request).then(r=>r||fetch(evt.request)));
  }
});
