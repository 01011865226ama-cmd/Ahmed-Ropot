// app.js — رسم الشبكة، معاينة، وتصدير PDF

// helpers
const mmToPx = (mm, dpi=300) => (dpi/25.4) * mm; // for PDF export

window.addEventListener('load', async ()=>{
  const canvas = document.getElementById('paperCanvas');
  const ctx = canvas.getContext('2d');
  const gridSizeEl = document.getElementById('gridSize');
  const lineWidthEl = document.getElementById('lineWidth');
  const lineWidthVal = document.getElementById('lineWidthVal');
  const lineColorEl = document.getElementById('lineColor');
  const bgColorEl = document.getElementById('bgColor');
  const btnPreview = document.getElementById('btnPreview');
  const btnExport = document.getElementById('btnExport');
  const btnSavePng = document.getElementById('btnSavePng');

  lineWidthVal.textContent = lineWidthEl.value;
  lineWidthEl.addEventListener('input', ()=>{ lineWidthVal.textContent = lineWidthEl.value; });

  // A4 preview size (scale down for screen). We'll use 210x297 mm at 150 dpi for nicer canvas resolution
  const previewDpi = 150;
  const a4mm = {w:210, h:297};

  function setCanvasSize(){
    // set canvas px size for preview
    const w = Math.round(mmToPx(a4mm.w, previewDpi));
    const h = Math.round(mmToPx(a4mm.h, previewDpi));
    canvas.width = w;
    canvas.height = h;
    canvas.style.width = Math.min(window.innerWidth - 360, 900) + 'px';
    canvas.style.height = (canvas.style.width.replace('px','') * h / w) + 'px';
  }

  function drawGrid(){
    const gridCm = parseFloat(gridSizeEl.value);
    const lineW = parseFloat(lineWidthEl.value);
    const lineC = lineColorEl.value;
    const bg = bgColorEl.value;

    // clear
    ctx.fillStyle = bg;
    ctx.fillRect(0,0,canvas.width,canvas.height);

    const pxPerCm = (previewDpi / 2.54);
    const step = pxPerCm * gridCm;

    ctx.strokeStyle = lineC;
    ctx.lineWidth = lineW;

    // vertical lines
    for(let x=0; x<=canvas.width+1; x+=step){
      ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,canvas.height); ctx.stroke();
    }
    // horizontal
    for(let y=0; y<=canvas.height+1; y+=step){
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(canvas.width,y); ctx.stroke();
    }
  }

  function updatePreview(){
    setCanvasSize();
    drawGrid();
  }

  btnPreview.addEventListener('click', updatePreview);
  window.addEventListener('resize', ()=>{ setCanvasSize(); drawGrid(); });

  // initial
  updatePreview();

  // export PDF
  btnExport.addEventListener('click', async ()=>{
    btnExport.disabled = true; btnExport.textContent = 'جارٍ التحضير...';
    // use html2canvas to render canvas at high DPI, then jsPDF
    // We'll create a temporary canvas at 300 DPI A4 size
    const dpi = 300;
    const w = Math.round(mmToPx(a4mm.w, dpi));
    const h = Math.round(mmToPx(a4mm.h, dpi));
    const temp = document.createElement('canvas');
    temp.width = w; temp.height = h;
    const tctx = temp.getContext('2d');

    // draw background
    tctx.fillStyle = bgColorEl.value; tctx.fillRect(0,0,w,h);
    // draw grid scaled
    const gridCm = parseFloat(gridSizeEl.value);
    const step = (dpi/2.54) * gridCm;
    tctx.strokeStyle = lineColorEl.value;
    tctx.lineWidth = parseFloat(lineWidthEl.value) * (dpi/150); // scale thickness

    for(let x=0; x<=w+1; x+=step){ tctx.beginPath(); tctx.moveTo(x,0); tctx.lineTo(x,h); tctx.stroke(); }
    for(let y=0; y<=h+1; y+=step){ tctx.beginPath(); tctx.moveTo(0,y); tctx.lineTo(w,y); tctx.stroke(); }

    try{
      // create PDF using jsPDF
      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF({unit:'px', format:[w,h]});
      const imgData = temp.toDataURL('image/png');
      pdf.addImage(imgData, 'PNG', 0, 0, w, h);
      const blob = pdf.output('blob');
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `GraphPaper_${Date.now()}.pdf`; document.body.appendChild(a); a.click(); a.remove();
      URL.revokeObjectURL(url);
    }catch(e){
      alert('Export failed: '+e.message);
    }
    btnExport.disabled = false; btnExport.textContent = 'تحميل PDF (A4)';
  });

  // save PNG (direct canvas snapshot)
  btnSavePng.addEventListener('click', ()=>{
    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = `GraphPaper_${Date.now()}.png`;
    document.body.appendChild(link); link.click(); link.remove();
  });

  // register service worker
  if('serviceWorker' in navigator){
    try{ await navigator.serviceWorker.register('service-worker.js'); console.log('SW registered'); }catch(e){console.warn('SW failed',e);}  }
});
